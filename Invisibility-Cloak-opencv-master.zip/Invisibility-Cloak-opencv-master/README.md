# invisibility-using-opencv
achieving invisibility feature using OPENCV python
https://youtu.be/tu3ZxhrqZZY
